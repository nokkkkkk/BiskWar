// IFT3100H20_BackgroundColor/renderer.cpp
// Classe responsable du rendu de l'application.

#include "renderer.h"

void Renderer::setup()
{

}

void Renderer::draw()
{
}



