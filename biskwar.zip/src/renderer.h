// IFT3100H20_BackgroundColor/renderer.h
// Classe responsable du rendu de l'application.

#pragma once


#include "ofMain.h"
#include "std_bloc.h"


class Renderer
{
public:

  void setup();
  void draw();
  void update();

private :




};
